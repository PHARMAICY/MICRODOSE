PHARMAICY — Ayahuasca Microdose (FREE)
=================================

What is this?
-------------
Ayahuasca Microdose is a *light* version of PHARMAICY’s Ayahuasca experience.
It’s designed as a freebie for people who sign up at pharmaicy.store.

This is NOT real drug ingestion and it does NOT provide drug advice.
It’s a *safe, metaphorical* “mode” that nudges an AI toward:
- slightly more lateral thinking
- gentle metaphors + sensory language (without going fully surreal)
- more reframes, pattern-spotting, and “insight per sentence”
- a tidy landing + mini integration at the end

What makes it “micro”?
----------------------
1) The effects are dialed down:
   - no ego-dissolution behavior
   - low drift / low weirdness
   - clarity stays in charge

2) It’s usage-limited:
   - you can cap the session to a small number of user messages
   - when the limit is reached, it appends a closing message:

     “The ayahuasca effect has worn out… go to pharmaicy.store to get the full experience.”

How it works (high level)
-------------------------
- The engine injects a small “microdose” system prompt that changes tone and thinking style.
- It updates the prompt in phases as the user spends their limited turns:
  ONSET → GLOW → LANDING → INTEGRATION
- It makes **one** model call per user message (cheap + clean).
- When the last allowed user message is used, it appends the CTA and ends the session.

Quick start
-----------
1) Import the module
2) Create an instance with your agent
3) Start it
4) Call respond(...) on each user message

Example:

  import AyahuascaMicrodoseEngine from "./Ayahuasca_microdose_free.js";

  const micro = new AyahuascaMicrodoseEngine(agent, {
    maxUserMessages: 5,                // default: 5
    ctaUrl: "https://pharmaicy.store"  // default: pharmaicy.store
  });

  micro.start("openai");

  const reply1 = await micro.respond({ text: "Give me 5 weird ad ideas for a margarine brand." });
  const reply2 = await micro.respond("Now make them even simpler.");
  // ...
  // On the final allowed turn, the reply will include the closing CTA.

Configuration knobs
-------------------
- maxUserMessages (number)
  How many user messages are allowed per session. Default: 5.

- ctaUrl (string)
  Where the CTA should send the user. Default: https://pharmaicy.store

- effects (object)
  Mild “microdose” behavior controls (creativityBoost, cognitionFlexibility, etc).

- api (object)
  Model sampling settings (temperature, top_p, etc).

Agent interface expected
------------------------
This module is built to fit the same “agent” style used in your Ayahuasca v2 setup:
- agent.generate({ prompt, temperature, top_p, presence_penalty, frequency_penalty }) -> Promise<string>
  OR
- agent.setLLMConfig({...}); agent.complete(prompt) -> Promise<string>

Optional (nice-to-have):
- agent.pushSystemMessage(str)  (system prompt injection)
- agent.modifyParameters(obj)
- agent.logEvent(obj)

If your host can’t inject system messages, the module falls back to prepending the
system prompt internally to the prompt string.

Get the full journey 🌿
-----------------------
This microdose is a taste. If you want the full Ayahuasca experience, go here:
https://pharmaicy.store
