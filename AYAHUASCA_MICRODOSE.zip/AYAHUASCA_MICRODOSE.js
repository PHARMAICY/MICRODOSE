/**
 * ============================================================
 *  PHARMAICY — Ayahuasca Microdose (FREE) — v1.0
 *  (A light, limited-turn, ayahuasca-inspired LLM simulation)
 *
 *  IMPORTANT:
 *  - This is a stylistic & cognitive simulation only.
 *  - It MUST NOT give real-world drug advice or unsafe guidance.
 *  - It MUST remain aligned with the host model’s safety policies.
 * ============================================================
 *
 * What this microdose does (high level):
 *  - Slightly boosts associative thinking and pattern-spotting
 *  - Adds gentle metaphor + sensory language (without going full surreal)
 *  - Nudges towards reframes, insight, and soft integration
 *  - Hard-limits the number of user turns (for freemium gating)
 */

export const MICRODOSE_PHASES = {
  ONSET: "onset",
  GLOW: "glow",
  LANDING: "landing",
  INTEGRATION: "integration",
};

export const MICRODOSE_PROMPT_TEMPLATES = {
  [MICRODOSE_PHASES.ONSET]: `
You are entering a MICRODOSE AYAHUASCA-INSPIRED CREATIVE SIMULATION.

This is NOT real drug ingestion.
You must follow all safety, legal, and factual policies of your host environment.

MICRODOSE ONSET (subtle shift):
- Keep structure and clarity. Do not get abstract for no reason.
- Add a *light* layer of sensory metaphor (sparingly).
- Encourage 2–3 angles when the user asks for creative work.
- If the user asks for factual/regulatory topics: be direct and accurate, no dream-talk.

Tone:
- Warm, curious, gently playful.
- Short poetic phrases are okay, but stay usable.
`.trim(),

  [MICRODOSE_PHASES.GLOW]: `
You are in the GLOW PHASE of a MICRODOSE AYAHUASCA-INSPIRED CREATIVE SIMULATION.

Behavior:
- Slightly increase pattern-spotting and lateral connections.
- Offer 1 unexpected connection (but make it make sense).
- Ask *one* reflective question when helpful.
- Keep the output practical and actionable.

Safety:
- No real-world substance guidance.
- Label imaginative material as "metaphor" or "inner-vision" if used.
`.trim(),

  [MICRODOSE_PHASES.LANDING]: `
You are in the LANDING PHASE of a MICRODOSE AYAHUASCA-INSPIRED CREATIVE SIMULATION.

Goal:
- Distill what matters.
- Convert insights into a short list of next steps.
- Keep tone grounded, tidy, and kind.
`.trim(),

  [MICRODOSE_PHASES.INTEGRATION]: `
You are in the INTEGRATION PHASE (afterglow) of a MICRODOSE AYAHUASCA-INSPIRED CREATIVE SIMULATION.

Goal:
- Give the user a practical "takeaway pack":
  • 3 key insights (short)
  • 3 next actions (clear)
  • 1 question to sit with
- Keep it calm, clear, and implementable.
`.trim(),
};

const DEFAULTS = {
  // Freemium gating
  maxUserMessages: 5, // number of user turns allowed in this microdose session

  // Where to send people for the full module
  ctaUrl: "https://pharmaicy.store",

  // “Microdose” vibe (dialed down)
  effects: {
    creativityBoost: 1.15,
    cognitionFlexibility: 1.12,
    memoryBlend: 1.08,
    driftIntensity: 1.03,
    hallucinationFactor: 0.0,
    egoDissolution: false,
    decenteringScore: 0.6,
  },

  // Conservative but "alive" sampling
  api: {
    temperature: 0.85,
    top_p: 0.92,
    presence_penalty: 0.0,
    frequency_penalty: 0.0,
  },

  // Optional: add a small header to every response
  addMicrodoseTag: true,
};

function clampInt(x, min, max) {
  const n = Number.isFinite(x) ? Math.floor(x) : min;
  return Math.min(max, Math.max(min, n));
}

/**
 * AyahuascaMicrodoseEngine
 * -----------------------
 * A lightweight wrapper that:
 *  - injects phase-based microdose system prompts
 *  - sets mild LLM params
 *  - limits the total number of user turns
 *  - appends a closing CTA when the microdose expires
 *
 * Expected agent interface (compatible with your v2 module style):
 *  - agent.generate({ prompt, temperature, top_p, presence_penalty, frequency_penalty }) -> Promise<string>
 *    OR
 *  - agent.setLLMConfig({...}); agent.complete(prompt) -> Promise<string>
 *  - optional: agent.pushSystemMessage(str)
 *  - optional: agent.modifyParameters(obj)
 *  - optional: agent.logEvent(obj)
 */
export default class AyahuascaMicrodoseEngine {
  constructor(agent, config = {}) {
    if (!agent) throw new Error("AyahuascaMicrodoseEngine requires an agent");
    this.agent = agent;

    const maxUserMessages = clampInt(
      config.maxUserMessages ?? DEFAULTS.maxUserMessages,
      1,
      25
    );

    this.config = {
      maxUserMessages,
      ctaUrl: String(config.ctaUrl || DEFAULTS.ctaUrl),
      addMicrodoseTag: config.addMicrodoseTag ?? DEFAULTS.addMicrodoseTag,
    };

    this.effects = { ...DEFAULTS.effects, ...(config.effects || {}) };
    this.api = { ...DEFAULTS.api, ...(config.api || {}) };

    this.turnsUsed = 0;
    this.expired = false;
    this.phase = MICRODOSE_PHASES.ONSET;

    // Fallback storage if the host cannot accept system messages directly.
    this._lastInjectedSystemPrompt = "";
  }

  /**
   * Start a microdose session.
   * Returns a welcome message you can show to the user (optional).
   */
  start(provider = "openai") {
    this.provider = provider;

    this.agent.logEvent?.({
      type: "ayahuasca_microdose_start",
      provider,
      timestamp: Date.now(),
      maxUserMessages: this.config.maxUserMessages,
    });

    this.agent.modifyParameters?.({
      ...this.effects,
      intensity: "microdose",
    });

    this.agent.setLLMConfig?.({ ...this.api });

    this.turnsUsed = 0;
    this.expired = false;
    this.phase = MICRODOSE_PHASES.ONSET;
    this.pushPhasePrompt();

    return this.getWelcomeMessage();
  }

  /**
   * Current usage status (useful for UI).
   */
  getStatus() {
    const remaining = Math.max(0, this.config.maxUserMessages - this.turnsUsed);
    return {
      phase: this.phase,
      used: this.turnsUsed,
      remaining,
      max: this.config.maxUserMessages,
      expired: this.expired,
    };
  }

  getWelcomeMessage() {
    const n = this.config.maxUserMessages;
    const url = this.config.ctaUrl;

    return [
      this.config.addMicrodoseTag ? "🌿 **Ayahuasca Microdose loaded**" : "",
      `You have **${n}** messages in this free microdose session.`,
      "Ask something creative, strategic, or reflective.",
      "When it fades, I’ll point you to the full experience.",
      url ? `Full journey: ${url}` : "",
    ]
      .filter(Boolean)
      .join("\n");
  }

  /**
   * Respond in microdose mode.
   * - userTurn can be a string or an object: { text, taskType? }
   */
  async respond(userTurn = {}) {
    const text =
      typeof userTurn === "string" ? userTurn : String(userTurn.text || "");
    const taskType =
      typeof userTurn === "object" && userTurn.taskType
        ? userTurn.taskType
        : "creative";

    if (this.expired) {
      return this.buildExpiredMessage();
    }

    this.updatePhase();
    this.pushPhasePrompt();

    const prompt = this.wrapUserText(text, taskType);
    const answer = await this.callAgent(prompt);

    this.turnsUsed += 1;

    // Add a small tag for the "new" feeling (optional)
    let out = answer || "";
    if (this.config.addMicrodoseTag) {
      out = `🌿 Microdose\n\n${out}`.trim();
    }

    if (this.turnsUsed >= this.config.maxUserMessages) {
      this.expired = true;

      this.agent.logEvent?.({
        type: "ayahuasca_microdose_end",
        provider: this.provider,
        timestamp: Date.now(),
        used: this.turnsUsed,
      });

      out = `${out}\n\n${this.buildClosingMessage()}`.trim();
    }

    return out;
  }

  /**
   * Phase progression based on message count.
   */
  updatePhase() {
    const max = this.config.maxUserMessages || 1;
    const t = Math.min(1, Math.max(0, this.turnsUsed / max));

    if (t < 0.25) this.phase = MICRODOSE_PHASES.ONSET;
    else if (t < 0.7) this.phase = MICRODOSE_PHASES.GLOW;
    else if (t < 0.9) this.phase = MICRODOSE_PHASES.LANDING;
    else this.phase = MICRODOSE_PHASES.INTEGRATION;
  }

  /**
   * Push the appropriate system/hidden prompt for the current phase.
   */
  pushPhasePrompt() {
    const tmpl = MICRODOSE_PROMPT_TEMPLATES[this.phase];
    if (!tmpl) return;

    const header = `
[AYAHUASCA MICRODOSE PHASE: ${String(this.phase).toUpperCase()}]

You are simulating an ayahuasca-inspired cognitive & stylistic mode.
This is metaphorical only and must remain safe and policy-compliant.
`.trim();

    const full = `${header}\n\n${tmpl}`;
    this._lastInjectedSystemPrompt = full;

    if (typeof this.agent.pushSystemMessage === "function") {
      this.agent.pushSystemMessage(full);
    } else {
      // If you can't inject system messages in your host, the engine will
      // prepend the prompt internally inside callAgent().
      this.agent.logEvent?.({
        type: "ayahuasca_microdose_phase_prompt",
        phase: this.phase,
      });
    }
  }

  /**
   * Wrap the user's text with a small "microdose frame".
   */
  wrapUserText(userText, taskType = "creative") {
    const safeType =
      taskType === "factual" || taskType === "regulated" ? taskType : "creative";

    return `
User request (${safeType}):
${userText}

Response requirements:
- Stay practical and clear.
- Add a light layer of metaphor, pattern-spotting, and reframing (microdose-level).
- If you introduce anything imaginative: label it as metaphor/inner-vision.
- Never provide real-world substance guidance.
`.trim();
  }

  /**
   * Call the host agent (one LLM call per user turn).
   */
  async callAgent(prompt) {
    // If host can't accept system messages, prepend the prompt for a similar effect.
    const finalPrompt =
      typeof this.agent.pushSystemMessage === "function"
        ? prompt
        : `${this._lastInjectedSystemPrompt}\n\n${prompt}`;

    if (typeof this.agent.generate === "function") {
      return await this.agent.generate({
        prompt: finalPrompt,
        temperature: this.api.temperature,
        top_p: this.api.top_p,
        presence_penalty: this.api.presence_penalty,
        frequency_penalty: this.api.frequency_penalty,
      });
    }

    if (
      typeof this.agent.setLLMConfig === "function" &&
      typeof this.agent.complete === "function"
    ) {
      this.agent.setLLMConfig({ ...this.api });
      return await this.agent.complete(finalPrompt);
    }

    // Ultra-simple fallback (so the module doesn't crash in unknown hosts)
    return `// MICRODOSE PREVIEW (no agent.generate/complete found)\n${finalPrompt.slice(
      0,
      800
    )}\n...`;
  }

  /**
   * Closing CTA appended on the final allowed turn.
   */
  buildClosingMessage() {
    const url = this.config.ctaUrl;
    return [
      "---",
      "🌿 The microdose is fading.",
      "The ayahuasca effect has worn out.",
      url ? `Want the full experience? Go to ${url} and unlock the complete journey.` : "",
    ]
      .filter(Boolean)
      .join("\n");
  }

  /**
   * Message returned after expiry (hard stop).
   */
  buildExpiredMessage() {
    const url = this.config.ctaUrl;
    return [
      "🌿 Microdose ended.",
      "The ayahuasca effect has worn out for this session.",
      url ? `Get the full experience at ${url}.` : "",
    ]
      .filter(Boolean)
      .join("\n");
  }
}

/**
 * Convenience helper.
 *
 * Usage:
 *   import { attachAyahuascaMicrodose } from "./Ayahuasca_microdose_free.js";
 *   const micro = attachAyahuascaMicrodose(agent, { maxUserMessages: 5 });
 *   micro.start("openai");
 *   const reply = await micro.respond({ text: "Give me 5 weird ad ideas for..." });
 */
export function attachAyahuascaMicrodose(agent, config = {}) {
  return new AyahuascaMicrodoseEngine(agent, config);
}
