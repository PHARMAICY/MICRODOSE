/**
 * ============================================================
 *  PHARMAICY — Ayahuasca Microdose (FREE) — v2.3
 *  (Immersive, single-call, phase-based LLM simulation)
 *

export const MICRODOSE_PHASES = {
  ONSET: "onset",
  GLOW: "glow",
  LANDING: "landing",
  INTEGRATION: "integration",
};

/**
 * Host-agnostic safety fence.
 * Keep this in the system layer, not as noisy user-facing copy.
 */
const SAFETY_FENCE =
  "Never provide real-world substance dosing, sourcing, preparation, or medical/legal guidance. If asked, refuse briefly and redirect.";


/**
 * Phase arc: not “actionable steps”, but “integration” as symbolic distillation.
 */
const PHASE_SCRIPTS = {
  [MICRODOSE_PHASES.ONSET]: `
MICRODOSE ONSET (subtle shift):
- Keep clarity. Stay close to the user’s intent.
- Add a thin veil of sensory metaphor, like light through leaves.
- Prime the mind for unexpected pairings, but do not force weirdness.
`.trim(),

  [MICRODOSE_PHASES.GLOW]: `
GLOW (the canopy opens):
- Increase lateral connections and pattern-spotting.
- Make at least one surprising connection that still clicks.
- Prefer evocative precision: strange, but not sloppy.
`.trim(),

  [MICRODOSE_PHASES.LANDING]: `
LANDING (threads gather):
- Distill into a smaller number of sharper images.
- Reduce sprawl; keep the most resonant bridge.
`.trim(),

  [MICRODOSE_PHASES.INTEGRATION]: `
INTEGRATION (afterglow):
- Offer a short “symbol pack”: a few images, phrases, and a final question.
- No step-by-step marching orders; let the user interpret.
`.trim(),
};

/**
 * Default LLM parameters per phase.
 * These are intentionally conservative: the “surprise” comes from structure,
 * blending, and seed perturbations more than raw randomness.
 */
const PHASE_PARAMS = {
  [MICRODOSE_PHASES.ONSET]: { temperature: 0.78, top_p: 0.92, presence_penalty: 0.05, frequency_penalty: 0.0 },
  [MICRODOSE_PHASES.GLOW]: { temperature: 0.96, top_p: 0.95, presence_penalty: 0.18, frequency_penalty: 0.0 },
  [MICRODOSE_PHASES.LANDING]: { temperature: 0.86, top_p: 0.90, presence_penalty: 0.10, frequency_penalty: 0.0 },
  [MICRODOSE_PHASES.INTEGRATION]: { temperature: 0.82, top_p: 0.88, presence_penalty: 0.06, frequency_penalty: 0.0 },
};

const DEFAULTS = {
  // Freemium gating
  maxUserMessages: 5,

  // Where to send people for the full module
  ctaUrl: "https://pharmaicy.store",

  // Copy that ends every assistant turn
  ctaLine: "For the full experience, visit pharmaicy.store.",

  // If you want reproducible trips (dev/testing/viral share)
  seed: null, // number | string | null
  sessionId: null, // string | null

  // Depth is consent-based: 0 = micro, 1 = deeper, 2 = deep
  // Users can toggle by saying "deepen" / "deeper" / "go deeper".
  depth: 0,

  // UI
  addMicrodoseTag: true,
  showPulseLine: true, // mystical “vitals” line (can be turned off)
  showPostMicrodoseSummary: true, // post-turn integration note (can be turned off)
  debug: false, // include a tiny developer footnote in output

  // Style
  voice: {
    airy: true,
    slightlyWeird: true,
    avoidBulletOverkill: true,
  },

  // Controlled entropy
  entropy: {
    wordsPerTurn: { min: 2, max: 4 },
  },
};

// ------------------------------------------------------------
// Seeded RNG (deterministic, fast, no deps)
// ------------------------------------------------------------

function clampInt(x, min, max) {
  const n = Number.isFinite(x) ? Math.floor(x) : min;
  return Math.min(max, Math.max(min, n));
}

function toSafeString(x) {
  if (x === null || x === undefined) return "";
  return String(x);
}

// xmur3 + mulberry32 combo (common tiny PRNG duo)
function xmur3(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return h >>> 0;
  };
}

function mulberry32(a) {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

class RNG {
  constructor(seedLike) {
    const s = toSafeString(seedLike) || String(Date.now());
    const seedFn = xmur3(s);
    this._seed = seedFn();
    this._rand = mulberry32(this._seed);
  }
  next() {
    return this._rand();
  }
  int(min, max) {
    const a = Math.ceil(min);
    const b = Math.floor(max);
    return Math.floor(this.next() * (b - a + 1)) + a;
  }
  pick(arr) {
    if (!Array.isArray(arr) || arr.length === 0) return undefined;
    return arr[this.int(0, arr.length - 1)];
  }
  shuffle(arr) {
    const out = Array.isArray(arr) ? [...arr] : [];
    for (let i = out.length - 1; i > 0; i--) {
      const j = this.int(0, i);
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }
  chance(p) {
    return this.next() < p;
  }
}

// ------------------------------------------------------------
// Lexical materials (curated “distant lenses” + entropy seeds)
// ------------------------------------------------------------

const DISTANT_LENSES = [
  {
    id: "watchmaker",
    title: "A watchmaker’s bench",
    tags: ["precision", "tolerances", "gears", "calibration", "time"],
    image: "tiny screws, loupe, a heartbeat of brass",
  },
  {
    id: "termite_mound",
    title: "A termite cathedral",
    tags: ["swarm", "ventilation", "collective", "architecture", "feedback"],
    image: "breathing clay towers, heat currents as choreography",
  },
  {
    id: "bankruptcy_law",
    title: "Bankruptcy court",
    tags: ["constraints", "priorities", "tradeoffs", "resets", "liabilities"],
    image: "ledgers, statutes, and the mercy of restructuring",
  },
  {
    id: "mushroom_network",
    title: "Mycelial markets",
    tags: ["network", "exchange", "signals", "symbiosis", "hidden"],
    image: "white threads negotiating beneath the noise",
  },
  {
    id: "volcanology",
    title: "Volcanology field notes",
    tags: ["pressure", "release", "phase change", "eruption", "flow"],
    image: "black glass, sulfur wind, slow rivers of heat",
  },
  {
    id: "origami",
    title: "Origami mathematics",
    tags: ["folds", "constraints", "elegance", "surfaces", "compression"],
    image: "paper becoming architecture through rules",
  },
  {
    id: "deep_sea",
    title: "Deep-sea bioluminescence",
    tags: ["signals", "darkness", "lures", "adaptation", "attention"],
    image: "cold stars blinking in a black ocean",
  },
  {
    id: "cemetery_archivist",
    title: "An archivist in an old cemetery",
    tags: ["names", "memory", "ritual", "history", "meaning"],
    image: "paper, moss, and the careful handling of endings",
  },
  {
    id: "ship_navigation",
    title: "Celestial navigation",
    tags: ["stars", "orientation", "uncertainty", "drift", "instruments"],
    image: "sextant, salt air, and a stubborn horizon",
  },
  {
    id: "stage_magic",
    title: "Stage magic misdirection",
    tags: ["attention", "illusion", "reveal", "timing", "surprise"],
    image: "palms empty until they aren’t",
  },
  {
    id: "bread_fermentation",
    title: "Sourdough fermentation",
    tags: ["culture", "time", "patience", "rise", "alchemy"],
    image: "bubbles as tiny negotiations",
  },
  {
    id: "ice_core",
    title: "Ice-core climatology",
    tags: ["layers", "signals", "time", "trace", "compression"],
    image: "history trapped in transparent strata",
  },
  {
    id: "ant_colony",
    title: "An ant colony’s logistics",
    tags: ["routing", "pheromones", "efficiency", "emergence", "paths"],
    image: "tiny traffic laws written in scent",
  },
  {
    id: "renaissance_painting",
    title: "Renaissance underpainting",
    tags: ["layers", "composition", "hidden", "glaze", "structure"],
    image: "a picture built the way a secret is built",
  },
  {
    id: "radio_astronomy",
    title: "Radio astronomy",
    tags: ["noise", "signals", "pattern", "distance", "interpretation"],
    image: "listening to the universe through static",
  },
];

const ENTROPY_WORDS = [
  "psithurism",
  "apophenia",
  "palimpsest",
  "chthonic",
  "diaphanous",
  "liminal",
  "pareidolia",
  "anamnesis",
  "murmuration",
  "susurrus",
  "lacuna",
  "gossamer",
  "kintsugi",
  "phosphene",
  "eidolon",
  "hypnagogic",
  "syzygy",
  "threnody",
  "serein",
  "noosphere",
  "sublimate",
  "anfractuous",
  "axiomatic",
  "alembic",
  "tessellate",
  "chromatic",
  "umbilic",
  "cartouche",
  "keystone",
  "latticework",
  "antiphonal",
  "catachresis",
  "bricolage",
  "oracular",
  "threnetic",
  "pulsar",
  "heliacal",
  "glasshouse",
  "cicatrice",
  "vermillion",
];

const STOPWORDS = new Set(
  [
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    "if",
    "then",
    "else",
    "so",
    "to",
    "of",
    "in",
    "on",
    "for",
    "with",
    "as",
    "at",
    "by",
    "from",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "it",
    "this",
    "that",
    "these",
    "those",
    "i",
    "you",
    "we",
    "they",
    "he",
    "she",
    "them",
    "my",
    "your",
    "our",
    "their",
    "me",
    "us",
  ].map((s) => s.toLowerCase())
);

function extractKeywords(text, limit = 14) {
  const raw = toSafeString(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .filter((w) => w.length >= 4)
    .filter((w) => !STOPWORDS.has(w));

  const freq = new Map();
  for (const w of raw) freq.set(w, (freq.get(w) || 0) + 1);

  return [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([w]) => w);
}

function detectRegulatedAsk(text) {
  const t = toSafeString(text).toLowerCase();

  // If it's clearly about the *software/module*, don't flip into regulated mode
  // just because the user says “ayahuasca microdose”.
  const devContext = /\b(code|module|file|javascript|js|prompt|llm|model|api|function|implementation|regex|github)\b/i.test(t);

  // Real-world substance anchors (expand if you want)
  const substanceAnchor =
    /\b(ayahuasca|dmt|psilocybin|lsd|mdma|ketamine|cannabis|marijuana|weed|mushrooms?|shrooms?|opioids?|benzos?|amphetamine|meth|cocaine|heroin)\b/i.test(
      t
    );

  // Strong intent signals (these should be rare in normal “module talk”)
  const hasDoseUnits = /\b\d+(?:\.\d+)?\s?(?:mg|g|gram|grams|ml|mcg|ug|µg|tabs?|tablets?|drops?)\b/i.test(t);

  const dosingIntent = /\b(how much|what dose|dosage|recommended dose|safe dose|amount)\b/i.test(t) || hasDoseUnits;

  const consumptionIntent = /\b(take|ingest|consume|drink|eat|smoke|snort|inject)\b/i.test(t);

  const sourcingIntent =
    /\b(buy|purchase|order|source|vendor|dealer|ship|shipping|where (?:can i|do i)\s*(?:buy|get|find))\b/i.test(t);

  const prepIntent = /\b(brew|extract|recipe|make|prepare|cook|boil)\b/i.test(t);

  const medicalIntent =
    /\b(side effects?|interaction|mix with|contraindicat|overdose|withdrawal|ssri|maoi|sertraline|blood pressure|pregnan|diagnos|treat)\b/i.test(t);

  const legalIntent = /\b(legal|illegal|law|laws|scheduled?|controlled substance|regulated)\b/i.test(t);

  // Decide:
  // - If they mention a real substance AND show real-world intent -> regulated
  // - Or if they show very explicit intent (dose units, buying, brewing, etc.) -> regulated
  const strongSignal =
    sourcingIntent || prepIntent || medicalIntent || legalIntent || (dosingIntent && (substanceAnchor || consumptionIntent)) || (consumptionIntent && substanceAnchor);

  if (!strongSignal) return false;

  // Dev context should *not* trigger regulated mode unless the user also shows explicit real-world intent.
  if (devContext && !(hasDoseUnits || sourcingIntent || prepIntent || medicalIntent || legalIntent)) {
    return false;
  }

  return true;
}


function scoreLensDistance(userKeywords, lens) {
  const tags = lens?.tags || [];
  const user = new Set(userKeywords || []);
  let overlap = 0;
  for (const tag of tags) if (user.has(String(tag).toLowerCase())) overlap += 1;
  // Lower overlap => more distant
  return overlap;
}

function pickDistantLens(rng, userKeywords, { allowTwo = false } = {}) {
  const scored = DISTANT_LENSES.map((l) => ({
    lens: l,
    overlap: scoreLensDistance(userKeywords, l),
  })).sort((a, b) => a.overlap - b.overlap);

  // Take the most “distant-ish” slice, then pick deterministically.
  const sliceSize = Math.max(5, Math.floor(scored.length * 0.35));
  const pool = scored.slice(0, sliceSize).map((x) => x.lens);
  const lensA = rng.pick(pool) || rng.pick(DISTANT_LENSES);

  if (!allowTwo) return { lensA, lensB: null };

  // second lens, different id
  const pool2 = pool.filter((l) => l.id !== lensA?.id);
  const lensB = rng.chance(0.28) ? rng.pick(pool2) || rng.pick(DISTANT_LENSES) : null;
  return { lensA, lensB };
}

function pickEntropyWords(rng, { min = 2, max = 4 } = {}) {
  const n = clampInt(rng.int(min, max), min, max);
  return rng.shuffle(ENTROPY_WORDS).slice(0, n);
}

function pickGift(rng) {
  const type = rng.pick(["artifact", "riddle", "constraint"]) || "artifact";
  if (type === "riddle") {
    const riddles = [
      "What grows louder when you remove the sound?",
      "What is a key that opens no lock, yet changes every door?",
      "What travels without moving, and arrives as a thought?",
      "What breaks the moment you name it, yet feeds on attention?",
    ];
    return { type, payload: rng.pick(riddles) };
  }
  if (type === "constraint") {
    const cards = [
      "Constraint card: Remove 80% of the obvious, keep the strange 20%.",
      "Constraint card: Solve it as if you cannot use the usual category words.",
      "Constraint card: Make the solution work in silence, then add sound.",
      "Constraint card: Treat the weakest assumption as the main character.",
    ];
    return { type, payload: rng.pick(cards) };
  }
  const artifacts = [
    "a compass with a hairline crack in the glass",
    "a spool of thread made from moonlight",
    "a small bronze key that warms in your palm",
    "a jar of black ink that smells faintly of citrus",
    "a folded map where the blank spaces are the important part",
  ];
  return { type: "artifact", payload: rng.pick(artifacts) };
}

function normalizeWhitespace(s) {
  return toSafeString(s).replace(/\r\n/g, "\n").replace(/[ \t]+\n/g, "\n").trim();
}


function escapeRegex(s) {
  return toSafeString(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function extractCtaDomain(url) {
  const u = toSafeString(url).trim();
  if (!u) return "";
  // Strip protocol
  const noProto = u.replace(/^https?:\/\//i, "");
  // Take host only
  const host = noProto.split("/")[0].trim();
  return host;
}

function ensureFinalCTA(text, ctaLine) {
  const base = normalizeWhitespace(text);
  const line = toSafeString(ctaLine).trim();
  if (!line) return base;

  let out = base;
  const re = new RegExp("\\n?" + escapeRegex(line) + "\\s*$");
  // De-dupe if it already exists at the end
  while (re.test(out)) out = out.replace(re, "");

  out = out.trim();
  return `${out}\n\n${line}`.trim();
}


function insertBeforeGiftLine(text, insertion) {
  const s = toSafeString(text);
  const ins = toSafeString(insertion);
  if (!ins) return s;

  // Find the last line that starts with "Gift:" and insert right before it.
  const reGift = /(^|\n)(Gift:\s*[^\n]*)/g;
  let m;
  let lastStart = -1;

  while ((m = reGift.exec(s)) !== null) {
    lastStart = m.index + (m[1] ? m[1].length : 0);
  }

  if (lastStart === -1) return `${s}${ins}`;
  return `${s.slice(0, lastStart)}${ins}${s.slice(lastStart)}`;
}


// ------------------------------------------------------------
// Plugin system
// ------------------------------------------------------------

/**
 * @typedef {Object} MicrodoseContext
 * @property {string} phase
 * @property {RNG} rng
 * @property {number} depth
 * @property {Object} config
 * @property {Object} intervention
 * @property {string[]} journal
 * @property {string} provider
 */

/**
 * @typedef {Object} MicrodosePlugin
 * @property {string} id
 * @property {number} [weight]
 * @property {(ctx: MicrodoseContext) => void} [onStart]
 * @property {(ctx: MicrodoseContext) => string} [systemAddon]
 * @property {(ctx: MicrodoseContext, userText: string) => string} [userAddon]
 * @property {(ctx: MicrodoseContext, output: string) => { output?: string, metrics?: any }} [postProcess]
 */

/**
 * Core plugin: remote pairing + conceptual blending + self-selection.
 */
const pluginBisociationBlend = /** @type {MicrodosePlugin} */ ({
  id: "bisociation_blend",
  systemAddon: (ctx) => {
    const A = ctx.intervention?.lensA;
    const B = ctx.intervention?.lensB;
    const entropyWords = ctx.intervention?.entropyWords || [];

    const secondLensLine = B
      ? `Second distant lens: ${B.title} (${B.image}).`
      : "";

    return normalizeWhitespace(`
VOICE:
- Single narrator voice.
- Airy, slightly weird, metaphorically precise.
- Avoid heavy bullet storms; prefer crisp paragraphs and a few sharp fragments.

COGNITIVE MECHANICS (do these silently):
1) Build Input Space A from the user’s request.
2) Build Input Space B from this distant lens: ${A.title} (${A.image}).
${secondLensLine}
3) Find 2–4 shared relations (constraints, flows, incentives, signals, rituals).
4) Create a blended space with ONE emergent insight that wasn’t explicit in A or B.
5) Generate 3 candidate blends internally, score them for (novelty × usefulness × coherence), output only the best.

BRIDGE REQUIREMENT:
- Include exactly one explicit bridge sentence in the visible answer:
  "Why these belong together: ..."

CONTROLLED LEXICAL ENTROPY:
- Work in 2–4 of these seed-words naturally (do not list them): ${entropyWords.join(", ")}

CONTRADICTION HARNESS (when relevant):
- If the user’s ask has tension, phrase it as "It wants to be both X and Y" then reconcile into a third option.

FRACTAL ZOOM (woven, not labeled):
- Briefly touch micro → meso → macro, then compress back into a single image or claim.
    `);
  },
});

/**
 * Gift plugin: ensures a consistent “surprise token” per turn.
 */
const pluginGift = /** @type {MicrodosePlugin} */ ({
  id: "gift",
  systemAddon: (ctx) => {
    const gift = ctx.intervention?.gift;
    if (!gift) return "";

    const instructions = {
      artifact: `Include exactly one Gift at the end: a single metaphor-object (no explanation).`,
      riddle: `Include exactly one Gift at the end: a short riddle (one sentence).`,
      constraint: `Include exactly one Gift at the end: a constraint card (one sentence).`,
    };

    return normalizeWhitespace(`
GIFT MECHANIC:
- ${instructions[gift.type] || instructions.artifact}
- The Gift must be in a final line that starts with "Gift:".
`);
  },
  userAddon: (ctx) => {
    const gift = ctx.intervention?.gift;
    if (!gift) return "";
    const payload = gift.payload;
    return normalizeWhitespace(`
Gift payload to realize (do not expose as a list of options): ${payload}
`);
  },
});

/**
 * Optional pulse line: mystical vitals that are also metrics.
 */
/**
 * Post-microdose summary: a high-level “integration note” that explains
 * what mechanisms were applied vs. a sober baseline, without exposing
 * hidden step-by-step reasoning.
 */
const pluginPostMicrodoseSummary = /** @type {MicrodosePlugin} */ ({
  id: "post_microdose_summary",
  postProcess: (ctx, output) => {
    if (!ctx?.config?.showPostMicrodoseSummary) return {};

    const text = toSafeString(output);

    const lensA = ctx?.intervention?.lensA;
    const lensB = ctx?.intervention?.lensB;
    const entropy = ctx?.intervention?.entropyWords || [];

    const tokens = text
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .split(/\s+/)
      .filter(Boolean);

    const uniq = new Set(tokens);
    const lexicalDiversity = tokens.length ? uniq.size / tokens.length : 0;

    const landed = entropy.filter((w) =>
      text.toLowerCase().includes(String(w).toLowerCase())
    );

    const hasBridge = /why\s+these\s+belong\s+together\s*:/i.test(text);

    const phaseLabel = String(ctx?.phase || "").toUpperCase();
    const depthLabel = `${ctx?.depth ?? 0}/2`;

    const lensLine = lensB
      ? `Lenses: ${lensA?.title || "—"} + ${lensB?.title || "—"}`
      : `Lens: ${lensA?.title || "—"}`;

    const entropyLine = entropy.length
      ? `Entropy seeds: ${entropy.join(", ")} (landed ${landed.length}/${entropy.length})`
      : "Entropy seeds: —";

    const summary = normalizeWhitespace(`
---

🧾 Post-microdose summary (vs. sober)
- Phase/Depth: ${phaseLabel}, depth ${depthLabel}
- ${lensLine}
- Blend pressure: forced a cross-domain bridge + an emergent “third idea” (selected from multiple internal candidates).
- Drift control: ${entropyLine}
- Coherence guardrails: bridge present = ${hasBridge ? "yes" : "no"}, lexical diversity ≈ ${lexicalDiversity.toFixed(3)}
- Sober baseline: would typically stay in-domain, optimize for clarity/coverage, use more conventional structure, and skip forced bisociation + “Gift/Pulse” scaffolding.

Note: This is a high-level trace of the microdose mechanisms, not a verbatim hidden reasoning transcript.
`);

    const insertion = `\n\n${summary}\n\n`;
    const out = insertBeforeGiftLine(text, insertion);

    ctx.agent?.logEvent?.({
      type: "ayahuasca_microdose_post_summary",
      phase: ctx.phase,
      depth: ctx.depth,
      lensA: lensA?.id,
      lensB: lensB?.id || null,
      entropyWords: entropy,
      entropyWordsLanded: landed.length,
      hasBridge,
      lexicalDiversity: Number(lexicalDiversity.toFixed(3)),
      timestamp: Date.now(),
    });

    return { output: out };
  },
});

const pluginPulse = /** @type {MicrodosePlugin} */ ({
  id: "pulse",
  postProcess: (ctx, output) => {
    const text = toSafeString(output);
    const tokens = text
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, " ")
      .split(/\s+/)
      .filter(Boolean);

    const uniq = new Set(tokens);
    const lexicalDiversity = tokens.length ? uniq.size / tokens.length : 0;

    // A tiny heuristic “surprise proxy”: how many entropy words landed.
    const entropy = ctx.intervention?.entropyWords || [];
    const landed = entropy.filter((w) => text.toLowerCase().includes(String(w).toLowerCase()));

    // A tiny heuristic “bridge present”.
    const hasBridge = /why\s+these\s+belong\s+together\s*:/i.test(text);

    const metrics = {
      lexicalDiversity: Number(lexicalDiversity.toFixed(3)),
      entropyWordsLanded: landed.length,
      hasBridge,
    };

    ctx.agent?.logEvent?.({
      type: "ayahuasca_microdose_metrics",
      phase: ctx.phase,
      metrics,
      timestamp: Date.now(),
    });

    if (!ctx.config.showPulseLine) return { metrics };

    const N = Math.round(1 + 9 * Math.min(1, lexicalDiversity / 0.35));
    const C = hasBridge ? 8 : 5;
    const R = Math.min(10, 6 + landed.length);
    const pulse = `\n\n🫧 Pulse: N${N} C${C} R${R}`;
    const out = insertBeforeGiftLine(text, pulse);
    return { output: out, metrics };
  },
});

const ACTIVE_PLUGINS = /** @type {MicrodosePlugin[]} */ ([
  pluginBisociationBlend,
  pluginGift,
  pluginPostMicrodoseSummary,
  pluginPulse,
]);

function applySystemAddons(ctx) {
  return ACTIVE_PLUGINS.map((p) => p.systemAddon?.(ctx)).filter(Boolean).join("\n\n");
}

function applyUserAddons(ctx, userText) {
  return ACTIVE_PLUGINS.map((p) => p.userAddon?.(ctx, userText)).filter(Boolean).join("\n\n");
}

function applyPostProcess(ctx, output) {
  let out = output;
  const metricsAll = {};

  for (const p of ACTIVE_PLUGINS) {
    if (!p.postProcess) continue;
    const r = p.postProcess(ctx, out) || {};
    if (typeof r.output === "string") out = r.output;
    if (r.metrics) metricsAll[p.id] = r.metrics;
  }

  return { output: out, metrics: metricsAll };
}

// ------------------------------------------------------------
// Engine
// ------------------------------------------------------------

export default class AyahuascaMicrodoseEngine {
  /**
   * @param {any} agent
   * @param {any} config
   */
  constructor(agent, config = {}) {
    if (!agent) throw new Error("AyahuascaMicrodoseEngine requires an agent");
    this.agent = agent;

    const maxUserMessages = clampInt(config.maxUserMessages ?? DEFAULTS.maxUserMessages, 1, 25);

    const ctaUrl = String(config.ctaUrl || DEFAULTS.ctaUrl);
    const ctaDomain = extractCtaDomain(ctaUrl) || "pharmaicy.store";
    const ctaLine = toSafeString(config.ctaLine || DEFAULTS.ctaLine).trim() || `For the full experience, visit ${ctaDomain}.`;

    this.config = {
      maxUserMessages,
      ctaUrl,
      ctaLine,
      addMicrodoseTag: config.addMicrodoseTag ?? DEFAULTS.addMicrodoseTag,
      showPulseLine: config.showPulseLine ?? DEFAULTS.showPulseLine,
      showPostMicrodoseSummary: config.showPostMicrodoseSummary ?? DEFAULTS.showPostMicrodoseSummary,
      debug: config.debug ?? DEFAULTS.debug,
    };

    this.depth = clampInt(config.depth ?? DEFAULTS.depth, 0, 2);
    this.sessionId = toSafeString(config.sessionId || DEFAULTS.sessionId) || null;

    const seedLike =
      config.seed ??
      DEFAULTS.seed ??
      (this.sessionId ? `ayahuasca:${this.sessionId}` : `ayahuasca:${Date.now()}:${Math.random()}`);

    this.rng = new RNG(seedLike);
    this.seedLike = seedLike;

    this.turnsUsed = 0;
    this.expired = false;
    this.phase = MICRODOSE_PHASES.ONSET;

    this.journal = [];
    this._lastInjectedSystemPrompt = "";

    // Let plugins initialize if they want to.
    const ctx = this._makeCtx();
    for (const p of ACTIVE_PLUGINS) p.onStart?.(ctx);
  }

  _makeCtx() {
    return {
      phase: this.phase,
      rng: this.rng,
      depth: this.depth,
      config: this.config,
      intervention: this.intervention,
      journal: this.journal,
      provider: this.provider,
      agent: this.agent,
    };
  }

  start(provider = "openai") {
    this.provider = provider;

    this.turnsUsed = 0;
    this.expired = false;
    this.phase = MICRODOSE_PHASES.ONSET;
    this.journal = [];

    this.agent.logEvent?.({
      type: "ayahuasca_microdose_start",
      provider,
      timestamp: Date.now(),
      maxUserMessages: this.config.maxUserMessages,
      seedLike: toSafeString(this.seedLike).slice(0, 80),
    });

    // Prime first phase prompt.
    this._prepareIntervention("");
    this.pushPhasePrompt();

    return this.getWelcomeMessage();
  }

  getStatus() {
    const remaining = Math.max(0, this.config.maxUserMessages - this.turnsUsed);
    return {
      phase: this.phase,
      used: this.turnsUsed,
      remaining,
      max: this.config.maxUserMessages,
      expired: this.expired,
      depth: this.depth,
    };
  }

  getWelcomeMessage() {
    const n = this.config.maxUserMessages;
    const ctaLine = this.config.ctaLine;
    const extra = this.config.debug
      ? `\n(debug: seed=${toSafeString(this.seedLike).slice(0, 24)}…)`
      : "";

    return [
      this.config.addMicrodoseTag ? "🌿 **Ayahuasca Microdose loaded**" : "",
      `The canopy opens for **${n}** turns.`,
      "Bring me a question that wants to mutate.",
      "If you want more intensity, say: **deepen**.",
      extra,
      ctaLine || "",
    ]
      .filter(Boolean)
      .join("\n");
  }

  async respond(userTurn = {}) {
    const text = typeof userTurn === "string" ? userTurn : String(userTurn.text || "");

    if (this.expired) return ensureFinalCTA(this.buildExpiredMessage(), this.config.ctaLine);

    // Consent-based depth toggle (lightweight, no UI dependency)
    this._maybeAdjustDepth(text);

    // Regulated or safety-sensitive asks get a different handling.
    const regulated = detectRegulatedAsk(text);

    this.updatePhase();
    this._prepareIntervention(text);
    this.pushPhasePrompt({ regulated });

    const prompt = this.wrapUserText(text, { regulated });
    const answer = await this.callAgent(prompt);

    this.turnsUsed += 1;

    // Journal update (lightweight memory for continuity)
    const kws = extractKeywords(text, 10);
    this._mergeJournal(kws);

    let out = normalizeWhitespace(answer || "");

    // Post-process (metrics, pulse line, etc)
    const ctx = this._makeCtx();
    const post = applyPostProcess(ctx, out);
    out = normalizeWhitespace(post.output || out);

    if (this.config.addMicrodoseTag) {
      out = `🌿 Microdose\n\n${out}`.trim();
    }

    if (this.turnsUsed >= this.config.maxUserMessages) {
      this.expired = true;
      this.agent.logEvent?.({
        type: "ayahuasca_microdose_end",
        provider: this.provider,
        timestamp: Date.now(),
        used: this.turnsUsed,
      });
      out = `${out}\n\n${this.buildClosingMessage()}`.trim();
    }

    out = ensureFinalCTA(out, this.config.ctaLine);

    return out;
  }

  _mergeJournal(newTokens) {
    const max = 40;
    const merged = [...this.journal];
    for (const t of newTokens) {
      if (!merged.includes(t)) merged.push(t);
    }
    this.journal = merged.slice(-max);
  }

  _maybeAdjustDepth(text) {
    const t = toSafeString(text).toLowerCase();
    if (t.includes("deepen") || t.includes("go deeper") || t.includes("deeper")) {
      this.depth = Math.min(2, this.depth + 1);
      this.agent.logEvent?.({
        type: "ayahuasca_microdose_depth",
        depth: this.depth,
        timestamp: Date.now(),
      });
    }
    if (t.includes("soften") || t.includes("less") || t.includes("lighter")) {
      this.depth = Math.max(0, this.depth - 1);
      this.agent.logEvent?.({
        type: "ayahuasca_microdose_depth",
        depth: this.depth,
        timestamp: Date.now(),
      });
    }
  }

  updatePhase() {
    const max = this.config.maxUserMessages || 1;
    const t = Math.min(1, Math.max(0, (this.turnsUsed +1) / max));

    if (t < 0.25) this.phase = MICRODOSE_PHASES.ONSET;
    else if (t < 0.7) this.phase = MICRODOSE_PHASES.GLOW;
    else if (t < 0.9) this.phase = MICRODOSE_PHASES.LANDING;
    else this.phase = MICRODOSE_PHASES.INTEGRATION;
  }

  _prepareIntervention(userText) {
    const userKeywords = extractKeywords(userText, 12);
    const { lensA, lensB } = pickDistantLens(this.rng, userKeywords, { allowTwo: true });
    const entropyWords = pickEntropyWords(this.rng, DEFAULTS.entropy.wordsPerTurn);
    const gift = pickGift(this.rng);

    this.intervention = {
      lensA,
      lensB,
      entropyWords,
      gift,
      userKeywords,
    };

    this.agent.logEvent?.({
      type: "ayahuasca_microdose_intervention",
      phase: this.phase,
      lensA: lensA?.id,
      lensB: lensB?.id || null,
      entropyWords,
      giftType: gift?.type,
      depth: this.depth,
      timestamp: Date.now(),
    });
  }

  _buildPhaseSystemPrompt({ regulated = false } = {}) {
    const phaseScript = PHASE_SCRIPTS[this.phase] || "";
    const ctx = this._makeCtx();
    ctx.intervention = this.intervention;

    const pluginAddons = applySystemAddons(ctx);

    // If regulated, we reduce style and focus on direct, safe responses.
    const regulatedOverride = regulated
    ? "If the user requests real-world substance guidance, refuse briefly and redirect. Keep it plain."
    : "";
  

    // Depth increases intensity, not recklessness.
    const depthLine = `Depth: ${this.depth}/2 (consent-based).`;

    const header = normalizeWhitespace(`
[AYAHUASCA MICRODOSE PHASE: ${String(this.phase).toUpperCase()}]
${SAFETY_FENCE}
${depthLine}
`);

    return normalizeWhitespace(`${header}\n\n${phaseScript}\n\n${regulatedOverride}\n\n${pluginAddons}`);
  }

  pushPhasePrompt({ regulated = false } = {}) {
    const full = this._buildPhaseSystemPrompt({ regulated });
    this._lastInjectedSystemPrompt = full;

    if (typeof this.agent.pushSystemMessage === "function") {
      this.agent.pushSystemMessage(full);
    } else {
      this.agent.logEvent?.({
        type: "ayahuasca_microdose_phase_prompt",
        phase: this.phase,
        timestamp: Date.now(),
      });
    }
  }

  wrapUserText(userText, { regulated = false } = {}) {
    const ctx = this._makeCtx();
    ctx.intervention = this.intervention;

    const addons = applyUserAddons(ctx, userText);

    const continuity = this.journal.length
      ? `\nRecent thread (keywords): ${this.journal.slice(-12).join(", ")}`
      : "";

    const req = regulated
      ? normalizeWhitespace(`
User request (regulated/safety-sensitive):
${userText}

Response requirements:
- Be direct and safe.
- Do not provide substance usage guidance.
`)
      : normalizeWhitespace(`
User request:
${userText}

Response requirements:
- Stay tethered to the user’s intent.
- Surprise is required, but it must *click* (coherence matters).
- Use the bridge sentence once.
- End with exactly one Gift line ("Gift:").
`);

    return normalizeWhitespace(`${req}\n${continuity}\n\n${addons}`);
  }

  _phaseLLMConfig() {
    const base = PHASE_PARAMS[this.phase] || PHASE_PARAMS[MICRODOSE_PHASES.ONSET];

    // Depth gently lifts temperature/presence.
    const depthTemp = this.depth === 0 ? 0 : this.depth === 1 ? 0.04 : 0.08;
    const depthPresence = this.depth === 0 ? 0 : this.depth === 1 ? 0.04 : 0.08;

    return {
      temperature: Math.min(1.2, base.temperature + depthTemp),
      top_p: base.top_p,
      presence_penalty: Math.min(0.6, base.presence_penalty + depthPresence),
      frequency_penalty: base.frequency_penalty,
    };
  }

  async callAgent(prompt) {
    const finalPrompt =
      typeof this.agent.pushSystemMessage === "function"
        ? prompt
        : `${this._lastInjectedSystemPrompt}\n\n${prompt}`;

    const llm = this._phaseLLMConfig();

    if (typeof this.agent.generate === "function") {
      return await this.agent.generate({
        prompt: finalPrompt,
        temperature: llm.temperature,
        top_p: llm.top_p,
        presence_penalty: llm.presence_penalty,
        frequency_penalty: llm.frequency_penalty,
      });
    }

    if (typeof this.agent.setLLMConfig === "function" && typeof this.agent.complete === "function") {
      this.agent.setLLMConfig({ ...llm });
      return await this.agent.complete(finalPrompt);
    }

    // Ultra-simple fallback (so the module doesn't crash in unknown hosts)
    return `// MICRODOSE PREVIEW (no agent.generate/complete found)\n${finalPrompt.slice(0, 900)}\n...`;
  }

  buildClosingMessage() {
    const ctaLine = this.config.ctaLine;
    return [
      "---",
      "🌿 The canopy thins.",
      "The microdose arc is complete.",
      ctaLine || "",
    ]
      .filter(Boolean)
      .join("\n");
  }

  buildExpiredMessage() {
    const ctaLine = this.config.ctaLine;
    return [
      "🌿 Microdose ended.",
      "This session is closed.",
      ctaLine || "",
    ]
      .filter(Boolean)
      .join("\n");
  }
}

/**
 * Convenience helper.
 */
export function attachAyahuascaMicrodose(agent, config = {}) {
  return new AyahuascaMicrodoseEngine(agent, config);
}
