PHARMAICY - Ayahuasca Microdose (FREE)
=================================

What is this?
-------------
Ayahuasca Microdose is a *light* version of PHARMAICY’s Ayahuasca experience.
It’s designed as a freebie for people who sign up at pharmaicy.store.

This README matches the implementation in **AYAHUASCA_MICRODOSE_v3.js**
(note: the file header labels the build as v2.3).

This is NOT real drug ingestion and it does NOT provide drug advice.
It’s a *safe, metaphorical* “mode” that nudges an AI toward:
- lateral thinking via cross-domain “lens blending” (bisociation)
- gentle sensory language (strange, but still tethered to the prompt)
- a forced bridge sentence that makes the weirdness *click*
- a tidy landing + an “integration note” after each turn (optional)

What makes it “micro”?
----------------------
1) The effects are dialed down:
   - no ego-dissolution behavior
   - controlled drift (entropy is seeded, not chaotic)
   - clarity and coherence stay in charge

2) It’s usage-limited:
   - you cap the session to a small number of user messages
   - when the limit is reached, it appends a closing message and ends the session

How it works (high level)
-------------------------
- The engine injects a microdose system prompt that changes tone + thinking style.
- It updates the system prompt in phases as the user spends their limited turns:
  ONSET → GLOW → LANDING → INTEGRATION
- It makes **one** model call per user message (cheap + clean).
- Each turn, it selects a “distant lens” (sometimes two) + a few entropy seed-words,
  then forces a conceptual blend with:
  - exactly one explicit bridge sentence: “Why these belong together: …”
  - exactly one “Gift:” line at the end (artifact/riddle/constraint)
- Optional UI add-ons can be inserted before the Gift:
  - 🫧 Pulse (lightweight metrics)
  - 🧾 Post-microdose summary (high-level trace vs. sober)
- Every assistant reply is guaranteed to end with the CTA line.

Quick start
-----------
1) Import the module
2) Create an instance with your agent
3) Start it
4) Call respond(...) on each user message

Example:

  import AyahuascaMicrodoseEngine from "./AYAHUASCA_MICRODOSE_v3.js";

  const micro = new AyahuascaMicrodoseEngine(agent, {
    maxUserMessages: 5,                         // default: 5 (clamped 1–25)
    ctaUrl: "https://pharmaicy.store",          // default: https://pharmaicy.store
    ctaLine: "For the full experience, visit pharmaicy.store.",

    // Optional:
    depth: 0,                                   // 0–2 (users can say “deepen”)
    seed: "shareable-trip-123",                // deterministic runs
    showPulseLine: true,                         // default: true
    showPostMicrodoseSummary: true,              // default: true
    addMicrodoseTag: true,                       // default: true
    debug: false                                 // default: false
  });

  const welcome = micro.start("openai");
  // (welcome is a string you can show to the user, if you want)

  const reply1 = await micro.respond({ text: "Give me 5 weird ad ideas for a margarine brand." });
  const reply2 = await micro.respond("Now make them even simpler.");
  // ...
  // On the final allowed turn, the reply will include the closing message.

Configuration knobs
-------------------
- maxUserMessages (number)
  How many user messages are allowed per session. Default: 5 (clamped 1–25).

- ctaUrl (string)
  Where the CTA should send the user. Default: https://pharmaicy.store

- ctaLine (string)
  The exact line that is appended to the end of every assistant reply.
  Default: “For the full experience, visit pharmaicy.store.”

- seed (string | number | null)
  Forces deterministic “trips” for testing / sharing.
  If omitted, the engine derives a seed from sessionId or current time.

- sessionId (string | null)
  Alternative way to get stable seeding without explicitly passing seed.

- depth (0 | 1 | 2)
  Consent-based intensity. Default: 0.
  Users can nudge it during the session by saying “deepen / deeper / go deeper”.
  (They can also reduce it with “soften / less / lighter”.)

- addMicrodoseTag (boolean)
  Prepends “🌿 Microdose” to each reply. Default: true.

- showPulseLine (boolean)
  Adds a “🫧 Pulse: …” line (light metrics) before the Gift line. Default: true.

- showPostMicrodoseSummary (boolean)
  Adds a “🧾 Post-microdose summary (vs. sober)” block before the Gift line.
  Default: true.

- debug (boolean)
  Adds a small seed hint in the welcome message. Default: false.

Agent interface expected
------------------------
This module is built to fit the same “agent” style used in your Ayahuasca setup:
- agent.generate({ prompt, temperature, top_p, presence_penalty, frequency_penalty }) -> Promise<string>
  OR
- agent.setLLMConfig({...}); agent.complete(prompt) -> Promise<string>

Optional (nice-to-have):
- agent.pushSystemMessage(str)  (system prompt injection)
- agent.logEvent(obj)           (telemetry hooks, phase + metrics)

If your host can’t inject system messages, the module falls back to prepending the
system prompt internally to the prompt string.

Get the full journey 🌿
-----------------------
This microdose is a taste. If you want the full Ayahuasca experience, go here:
https://pharmaicy.store
